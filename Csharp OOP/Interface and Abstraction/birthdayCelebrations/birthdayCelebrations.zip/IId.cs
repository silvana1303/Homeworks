﻿namespace borderControl
{
    public interface IId
    {
        public string Id { get;  }
    }
}