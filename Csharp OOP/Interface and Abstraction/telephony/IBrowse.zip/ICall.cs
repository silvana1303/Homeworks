﻿using System;

namespace telephony
{
    public interface ICall
    {
        public void Call(string phone);

    }
}