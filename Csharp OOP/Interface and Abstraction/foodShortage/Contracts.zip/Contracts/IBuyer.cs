﻿namespace foodShortage
{
    public interface IBuyer
    {
        public int Food { get; }

        void BuyFood();
    }
}