﻿namespace borderControl
{
    public interface IName
    {
        public string Name { get; set; }
    }
}