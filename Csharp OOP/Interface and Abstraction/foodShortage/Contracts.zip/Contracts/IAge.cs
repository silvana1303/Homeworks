﻿namespace foodShortage
{
    public interface IAge
    {
        public int Age { get; }
    }
}