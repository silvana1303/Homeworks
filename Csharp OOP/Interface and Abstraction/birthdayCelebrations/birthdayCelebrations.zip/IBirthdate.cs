﻿namespace borderControl
{
    public interface IBirthdate
    {
        public string Birthdate { get; set; }
    }
}