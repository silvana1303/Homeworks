﻿using System;

namespace telephony
{
    public interface IBrowse
    {
        public void Browse(string link);

    }
}